#!/bin/bash

apidoc -i ./ -o ./lazycat

open ./lazycat/index.html
